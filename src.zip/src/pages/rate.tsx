import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Star, Send, ChevronLeft, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import {
  useGetServiceRequest,
  getGetServiceRequestQueryKey,
  useCreateReview,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

export default function Rate() {
  const { id } = useParams();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [rating, setRating] = useState(0);
  const [hovered, setHovered] = useState(0);
  const [comment, setComment] = useState("");

  useEffect(() => {
    if (!user) setLocation("/login");
  }, [user]);

  const requestId = parseInt(id ?? "0");
  const { data: request, isLoading } = useGetServiceRequest(requestId, {
    query: { enabled: !!requestId, queryKey: getGetServiceRequestQueryKey(requestId) },
  });

  const reviewMutation = useCreateReview({
    mutation: {
      onSuccess: () => {
        toast({ title: "Thank you for your review!" });
        setLocation("/client-dashboard");
      },
      onError: () => toast({ title: "Failed to submit review", variant: "destructive" }),
    },
  });

  if (!user) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!request?.mechanic || !rating) return;
    reviewMutation.mutate({
      data: {
        requestId: request.id,
        userId: user.id,
        mechanicId: request.mechanic.id,
        rating,
        comment: comment || null,
      },
    });
  };

  return (
    <Layout>
      <div className="max-w-sm mx-auto px-4 py-6">
        <button onClick={() => setLocation("/client-dashboard")} className="flex items-center gap-1 text-sm text-muted-foreground mb-5">
          <ChevronLeft className="h-4 w-4" /> Back
        </button>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl font-bold mb-1">Rate Your Service</h1>
          <p className="text-muted-foreground text-sm mb-6">Share your experience</p>

          {isLoading ? (
            <div className="flex justify-center py-8"><Loader className="h-8 w-8 animate-spin text-primary" /></div>
          ) : request ? (
            <div className="bg-card border border-card-border rounded-2xl p-6">
              {/* Mechanic Info */}
              {request.mechanic && (
                <div className="flex items-center gap-3 mb-6 pb-5 border-b border-border">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary font-bold">{request.mechanic.name[0]}</span>
                  </div>
                  <div>
                    <p className="font-semibold">{request.mechanic.name}</p>
                    <p className="text-sm text-muted-foreground">{request.mechanic.specialization}</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Star Rating */}
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-3">How was your experience?</p>
                  <div className="flex justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <button
                        key={n}
                        type="button"
                        data-testid={`star-${n}`}
                        onMouseEnter={() => setHovered(n)}
                        onMouseLeave={() => setHovered(0)}
                        onClick={() => setRating(n)}
                      >
                        <motion.div whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}>
                          <Star
                            className={`h-10 w-10 transition-colors ${
                              n <= (hovered || rating)
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-muted-foreground/30"
                            }`}
                          />
                        </motion.div>
                      </button>
                    ))}
                  </div>
                  {rating > 0 && (
                    <p className="text-sm font-medium mt-2 text-primary">
                      {["", "Poor", "Fair", "Good", "Very Good", "Excellent"][rating]}
                    </p>
                  )}
                </div>

                {/* Comment */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Your Review (optional)</label>
                  <Textarea
                    data-testid="input-comment"
                    placeholder="Tell us about your experience..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button
                  data-testid="button-submit-review"
                  type="submit"
                  className="w-full"
                  disabled={!rating || reviewMutation.isPending}
                >
                  {reviewMutation.isPending ? "Submitting..." : "Submit Review"}
                  <Send className="ml-2 h-4 w-4" />
                </Button>
              </form>
            </div>
          ) : (
            <p className="text-center text-muted-foreground">Request not found</p>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
