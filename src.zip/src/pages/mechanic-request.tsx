import { useState, useEffect } from "react";
import { useParams, useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { ChevronLeft, MapPin, Phone, MessageSquare, Plus, Trash, CheckCircle, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import {
  useGetServiceRequest,
  getGetServiceRequestQueryKey,
  useUpdateServiceStatus,
  useAddDiagnosis,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

const STATUS_STEPS = [
  { key: "coming", label: "Mark as Coming" },
  { key: "towed", label: "Car Towed to Shop" },
  { key: "diagnosing", label: "Start Diagnosis" },
  { key: "repairing", label: "Start Repair" },
  { key: "ready", label: "Mark Ready" },
  { key: "delivered", label: "Mark Delivered" },
];

const PRESET_REPAIRS = [
  { name: "Brake Change", price: 2500 },
  { name: "Engine Oil Change", price: 1500 },
  { name: "AC Repair", price: 3500 },
  { name: "Battery Replacement", price: 5000 },
  { name: "Tyre Puncture Repair", price: 500 },
  { name: "Spark Plug Change", price: 800 },
];

interface DiagnosisItem { name: string; price: number; }

export default function MechanicRequest() {
  const { id } = useParams();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [diagnosisItems, setDiagnosisItems] = useState<DiagnosisItem[]>([]);
  const [customName, setCustomName] = useState("");
  const [customPrice, setCustomPrice] = useState("");

  useEffect(() => {
    if (!user || user.role !== "mechanic") setLocation("/login");
  }, [user]);

  const requestId = parseInt(id ?? "0");
  const { data: request, isLoading } = useGetServiceRequest(requestId, {
    query: { enabled: !!requestId, queryKey: getGetServiceRequestQueryKey(requestId) },
  });

  useEffect(() => {
    if (request?.diagnosisItems) {
      try { setDiagnosisItems(JSON.parse(request.diagnosisItems)); } catch {}
    }
  }, [request?.diagnosisItems]);

  const statusMutation = useUpdateServiceStatus({
    mutation: {
      onSuccess: () => {
        toast({ title: "Status updated" });
        queryClient.invalidateQueries({ queryKey: getGetServiceRequestQueryKey(requestId) });
      },
      onError: () => toast({ title: "Failed to update", variant: "destructive" }),
    },
  });

  const diagnosisMutation = useAddDiagnosis({
    mutation: {
      onSuccess: () => {
        toast({ title: "Diagnosis saved" });
        queryClient.invalidateQueries({ queryKey: getGetServiceRequestQueryKey(requestId) });
      },
      onError: () => toast({ title: "Failed to save", variant: "destructive" }),
    },
  });

  if (!user || user.role !== "mechanic") return null;

  const nextStep = STATUS_STEPS.find((s) => {
    const currentIdx = STATUS_STEPS.findIndex((st) => st.key === request?.status);
    return currentIdx === -1 ? s.key === "coming" : STATUS_STEPS.indexOf(s) === currentIdx + 1;
  });

  const addPreset = (item: DiagnosisItem) => {
    if (!diagnosisItems.find((d) => d.name === item.name)) {
      setDiagnosisItems([...diagnosisItems, item]);
    }
  };

  const removeItem = (name: string) => setDiagnosisItems(diagnosisItems.filter((d) => d.name !== name));

  const addCustom = () => {
    if (customName && customPrice) {
      setDiagnosisItems([...diagnosisItems, { name: customName, price: parseFloat(customPrice) }]);
      setCustomName("");
      setCustomPrice("");
    }
  };

  const totalCost = diagnosisItems.reduce((sum, i) => sum + i.price, 0);

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6">
        <button onClick={() => setLocation("/mechanic-dashboard")} className="flex items-center gap-1 text-sm text-muted-foreground mb-5">
          <ChevronLeft className="h-4 w-4" /> Dashboard
        </button>

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader className="h-8 w-8 animate-spin text-primary" /></div>
        ) : request ? (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
            <div>
              <p className="text-sm text-muted-foreground">Request #{request.id}</p>
              <h1 className="text-xl font-bold mt-0.5">{request.issueDescription}</h1>
            </div>

            {/* Client Info */}
            <div className="bg-card border border-card-border rounded-2xl p-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-3">Client</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <span className="font-bold">{request.user?.name?.[0]}</span>
                  </div>
                  <div>
                    <p className="font-semibold">{request.user?.name}</p>
                    <p className="text-sm text-muted-foreground">{request.user?.phone}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {request.user?.phone && (
                    <a href={`tel:${request.user.phone}`}>
                      <Button size="icon" variant="outline" className="h-9 w-9"><Phone className="h-4 w-4" /></Button>
                    </a>
                  )}
                  <Button size="icon" variant="outline" className="h-9 w-9" asChild>
                    <Link href={`/chat/${request.id}`}><MessageSquare className="h-4 w-4" /></Link>
                  </Button>
                </div>
              </div>
              {request.locationAddress && (
                <div className="flex items-center gap-2 mt-3 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4 text-primary" />
                  {request.locationAddress}
                </div>
              )}
            </div>

            {/* Status Update */}
            <div className="bg-card border border-card-border rounded-2xl p-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-3">Current Status</p>
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium capitalize">{request.status}</span>
              </div>
              {nextStep && (
                <Button
                  data-testid="button-update-status"
                  className="w-full"
                  onClick={() => statusMutation.mutate({ id: request.id, data: { status: nextStep.key } })}
                  disabled={statusMutation.isPending}
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  {nextStep.label}
                </Button>
              )}
            </div>

            {/* Diagnosis */}
            <div className="bg-card border border-card-border rounded-2xl p-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-3">Diagnosis & Repairs</p>

              <div className="flex flex-wrap gap-2 mb-4">
                {PRESET_REPAIRS.map((item) => (
                  <button
                    key={item.name}
                    data-testid={`button-preset-${item.name}`}
                    onClick={() => addPreset(item)}
                    className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                      diagnosisItems.find((d) => d.name === item.name)
                        ? "bg-primary text-primary-foreground border-primary"
                        : "border-border hover:border-primary hover:text-primary"
                    }`}
                  >
                    {item.name} — Rs {item.price.toLocaleString()}
                  </button>
                ))}
              </div>

              <div className="flex gap-2 mb-4">
                <Input placeholder="Repair name" value={customName} onChange={(e) => setCustomName(e.target.value)} className="flex-1" />
                <Input placeholder="Price" type="number" value={customPrice} onChange={(e) => setCustomPrice(e.target.value)} className="w-24" />
                <Button size="icon" variant="outline" onClick={addCustom}><Plus className="h-4 w-4" /></Button>
              </div>

              {diagnosisItems.length > 0 && (
                <div className="space-y-2 mb-4">
                  {diagnosisItems.map((item) => (
                    <div key={item.name} className="flex items-center justify-between bg-muted/50 rounded-lg px-3 py-2">
                      <span className="text-sm">{item.name}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium">Rs {item.price.toLocaleString()}</span>
                        <button onClick={() => removeItem(item.name)} className="text-destructive">
                          <Trash className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                  <div className="flex items-center justify-between px-3 py-2 font-bold">
                    <span>Total</span>
                    <span>Rs {totalCost.toLocaleString()}</span>
                  </div>
                </div>
              )}

              <Button
                data-testid="button-save-diagnosis"
                className="w-full"
                variant="outline"
                disabled={diagnosisItems.length === 0 || diagnosisMutation.isPending}
                onClick={() => diagnosisMutation.mutate({ id: request.id, data: { items: diagnosisItems } })}
              >
                Save Diagnosis
              </Button>
            </div>
          </motion.div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">Request not found</div>
        )}
      </div>
    </Layout>
  );
}
