import { Link } from "wouter";
import { motion } from "framer-motion";
import { Wrench, MapPin, Shield, Clock, Star, ChevronRight, Phone, CheckCircle, Zap, Users, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";

const SERVICES = [
  { icon: Zap, title: "Emergency Towing", desc: "24/7 roadside assistance and towing to nearest workshop" },
  { icon: Wrench, title: "On-Site Repairs", desc: "Certified mechanics come to your location and fix on the spot" },
  { icon: Shield, title: "Battery & Tyres", desc: "Jump-starts, tyre changes, and battery replacements" },
  { icon: Clock, title: "Fast Response", desc: "Average mechanic arrival in under 20 minutes" },
];

const HOW_IT_WORKS = [
  { step: "01", title: "Describe Your Issue", desc: "Tell us what's wrong with your car — engine, battery, tyres, or anything else." },
  { step: "02", title: "Get Matched Instantly", desc: "We find the nearest available certified mechanic to your location." },
  { step: "03", title: "Track Live", desc: "Watch your mechanic arrive in real-time with live tracking and chat." },
  { step: "04", title: "Problem Solved", desc: "Get a transparent cost breakdown and pay after the job is done." },
];

const TESTIMONIALS = [
  { name: "Ayesha M.", location: "DHA, Karachi", rating: 5, text: "My car broke down at midnight. MechConnect had a mechanic at my door in 18 minutes. Absolute lifesaver." },
  { name: "Hassan R.", location: "Gulshan, Karachi", rating: 5, text: "Battery died before an important meeting. The mechanic was professional, fast, and the price was fair." },
  { name: "Fatima K.", location: "Clifton, Karachi", rating: 5, text: "Used it twice now. The live tracking feature is exactly like Uber — you always know where help is." },
];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[1,2,3,4,5].map(n => (
        <Star key={n} className={`h-4 w-4 ${n <= rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"}`} />
      ))}
    </div>
  );
}

export default function Landing() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 flex items-center justify-between px-5 sm:px-8 h-14 border-b border-border/40 bg-background/90 backdrop-blur">
        <Link href="/" className="flex items-center gap-2 font-bold text-lg">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Wrench className="h-4 w-4 text-primary-foreground" />
          </div>
          Mech<span className="text-primary">Connect</span>
        </Link>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/login">Log in</Link>
          </Button>
          <Button size="sm" asChild>
            <Link href="/register">Get Started</Link>
          </Button>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden px-5 sm:px-8 pt-16 pb-20 sm:pt-24 sm:pb-28">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-2xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-5">
              <MapPin className="h-3 w-3" /> Available across Karachi 24/7
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold leading-tight mb-5">
              Car broke down?<br />
              <span className="text-primary">Help is 15 minutes away.</span>
            </h1>
            <p className="text-muted-foreground text-lg mb-8 max-w-lg mx-auto">
              Connect with certified mechanics instantly. Real-time tracking, transparent pricing, and professional service — right where you are.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button size="lg" className="text-base px-8" asChild>
                <Link href="/register">
                  Get Help Now <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-base px-8" asChild>
                <Link href="/register?role=mechanic">Join as Mechanic</Link>
              </Button>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="grid grid-cols-3 gap-4 mt-14 max-w-sm mx-auto"
          >
            {[
              { value: "2,400+", label: "Jobs Done" },
              { value: "4.9", label: "Avg Rating" },
              { value: "18 min", label: "Avg Arrival" },
            ].map(({ value, label }) => (
              <div key={label} className="text-center">
                <p className="text-2xl font-bold text-primary">{value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Services */}
      <section className="px-5 sm:px-8 py-16 bg-muted/30">
        <div className="max-w-2xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-10">
            <h2 className="text-3xl font-bold">Everything you need on the road</h2>
            <p className="text-muted-foreground mt-2">Comprehensive breakdown coverage, whenever and wherever</p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {SERVICES.map(({ icon: Icon, title, desc }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="bg-card border border-card-border rounded-2xl p-5"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold mb-1">{title}</h3>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="px-5 sm:px-8 py-16">
        <div className="max-w-2xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-10">
            <h2 className="text-3xl font-bold">How it works</h2>
            <p className="text-muted-foreground mt-2">Help in four simple steps</p>
          </motion.div>
          <div className="space-y-4">
            {HOW_IT_WORKS.map(({ step, title, desc }, i) => (
              <motion.div
                key={step}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="flex items-start gap-4 bg-card border border-card-border rounded-2xl p-5"
              >
                <span className="text-3xl font-bold text-primary/30 font-mono leading-none">{step}</span>
                <div>
                  <h3 className="font-semibold">{title}</h3>
                  <p className="text-sm text-muted-foreground mt-0.5">{desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="px-5 sm:px-8 py-16 bg-muted/30">
        <div className="max-w-2xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-10">
            <h2 className="text-3xl font-bold">Trusted by thousands</h2>
            <p className="text-muted-foreground mt-2">Real stories from real customers</p>
          </motion.div>
          <div className="space-y-4">
            {TESTIMONIALS.map(({ name, location, rating, text }, i) => (
              <motion.div
                key={name}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="bg-card border border-card-border rounded-2xl p-5"
              >
                <StarRating rating={rating} />
                <p className="text-sm text-muted-foreground mt-3 leading-relaxed">"{text}"</p>
                <div className="flex items-center gap-2 mt-4">
                  <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary text-xs font-bold">{name[0]}</span>
                  </div>
                  <div>
                    <p className="text-xs font-semibold">{name}</p>
                    <p className="text-xs text-muted-foreground">{location}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-5 sm:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-lg mx-auto bg-primary rounded-3xl p-8 text-center"
        >
          <div className="w-12 h-12 rounded-2xl bg-primary-foreground/20 flex items-center justify-center mx-auto mb-4">
            <Phone className="h-6 w-6 text-primary-foreground" />
          </div>
          <h2 className="text-2xl font-bold text-primary-foreground mb-2">Ready when you need us</h2>
          <p className="text-primary-foreground/80 mb-6 text-sm">Create your free account in 30 seconds. No subscription required.</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/register">Get Started Free</Link>
            </Button>
            <Button size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" asChild>
              <Link href="/register?role=mechanic">
                <Users className="mr-2 h-4 w-4" /> Join as Mechanic
              </Link>
            </Button>
          </div>
          <div className="flex items-center justify-center gap-4 mt-6 text-primary-foreground/60 text-xs">
            <span className="flex items-center gap-1"><CheckCircle className="h-3 w-3" /> Free to use</span>
            <span className="flex items-center gap-1"><CheckCircle className="h-3 w-3" /> No hidden fees</span>
            <span className="flex items-center gap-1"><CheckCircle className="h-3 w-3" /> 24/7 support</span>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="px-5 sm:px-8 py-8 border-t border-border/40">
        <div className="max-w-2xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 font-bold">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <Wrench className="h-3.5 w-3.5 text-primary-foreground" />
            </div>
            MechConnect
          </div>
          <p className="text-xs text-muted-foreground">© 2026 MechConnect. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <Link href="/login" className="hover:text-primary">Login</Link>
            <Link href="/register" className="hover:text-primary">Sign up</Link>
            <Link href="/reviews" className="hover:text-primary">Reviews</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
