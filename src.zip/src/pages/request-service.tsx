import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { MapPin, Camera, Send, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { useCreateServiceRequest } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

const COMMON_ISSUES = [
  "Car Wash",
  "Vacuuming Interior",
  "Interior Detailing",
  "Exterior Detailing",
  "Exterior Wash & Polishing",
  "Cabin Washing",
];

export default function RequestService() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [form, setForm] = useState({
    issueDescription: "",
    locationAddress: "",
    locationLat: null as number | null,
    locationLng: null as number | null,
  });

  useEffect(() => {
    if (!user) setLocation("/login");
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        setForm((f) => ({ ...f, locationLat: pos.coords.latitude, locationLng: pos.coords.longitude }));
      });
    }
  }, [user]);

  const createMutation = useCreateServiceRequest({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Booking sent!", description: "We're finding the right team for you." });
        setLocation(`/tracking/${data.id}`);
      },
      onError: () => {
        toast({ title: "Failed to send request", variant: "destructive" });
      },
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !form.issueDescription.trim()) return;
    createMutation.mutate({
      data: {
        userId: user.id,
        issueDescription: form.issueDescription,
        locationAddress: form.locationAddress || null,
        locationLat: form.locationLat,
        locationLng: form.locationLng,
      },
    });
  };

  const handleServiceToggle = (service: string) => {
    const current = form.issueDescription;
    const services = current ? current.split(", ").map(s => s.trim()).filter(Boolean) : [];
    const idx = services.indexOf(service);
    if (idx >= 0) {
      services.splice(idx, 1);
    } else {
      services.push(service);
    }
    setForm({ ...form, issueDescription: services.join(", ") });
  };

  if (!user) return null;

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <button onClick={() => setLocation("/client-dashboard")} className="flex items-center gap-1 text-sm text-muted-foreground mb-5">
            <ChevronLeft className="h-4 w-4" /> Back
          </button>
          <h1 className="text-2xl font-bold mb-1">Book a Car Service</h1>
          <p className="text-muted-foreground text-sm mb-6">Select a service and we'll find the right team for you</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Quick Issues */}
            <div>
              <Label className="mb-2 block">Select Services</Label>
              <div className="flex flex-wrap gap-2">
                {COMMON_ISSUES.map((issue) => {
                  const selected = form.issueDescription.split(", ").map(s => s.trim()).includes(issue);
                  return (
                    <button
                      key={issue}
                      type="button"
                      data-testid={`button-issue-${issue}`}
                      onClick={() => handleServiceToggle(issue)}
                      className={`px-3 py-1.5 text-xs rounded-full border transition-all ${
                        selected
                          ? "bg-primary text-primary-foreground border-primary"
                          : "border-border text-muted-foreground hover:border-primary hover:text-primary"
                      }`}
                    >
                      {issue}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Additional Notes</Label>
              <Textarea
                id="description"
                data-testid="input-description"
                placeholder="Any specific requests or details about your car (optional)..."
                rows={4}
                value={form.issueDescription}
                onChange={(e) => setForm({ ...form, issueDescription: e.target.value })}
              />
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location">Your Location</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="location"
                  data-testid="input-location"
                  className="pl-9"
                  placeholder="Enter your address (e.g. DHA Phase 6, Karachi)"
                  value={form.locationAddress}
                  onChange={(e) => setForm({ ...form, locationAddress: e.target.value })}
                />
              </div>
              {form.locationLat && (
                <p className="text-xs text-muted-foreground">
                  GPS: {form.locationLat.toFixed(4)}, {form.locationLng?.toFixed(4)}
                </p>
              )}
            </div>

            {/* Photo placeholder */}
            <div className="border-2 border-dashed border-border rounded-xl p-6 text-center">
              <Camera className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Upload car photo (optional)</p>
              <p className="text-xs text-muted-foreground mt-1">Tap to select from gallery</p>
            </div>

            <Button
              data-testid="button-request"
              type="submit"
              size="lg"
              className="w-full"
              disabled={createMutation.isPending || !form.issueDescription.trim()}
            >
              {createMutation.isPending ? "Booking..." : "Book Service"}
              <Send className="ml-2 h-4 w-4" />
            </Button>
          </form>
        </motion.div>
      </div>
    </Layout>
  );
}
