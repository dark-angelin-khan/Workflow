import { motion } from "framer-motion";
import { Star, Loader } from "lucide-react";
import { useListReviews, getListReviewsQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <Star key={n} className={`h-4 w-4 ${n <= rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/40"}`} />
      ))}
    </div>
  );
}

export default function Reviews() {
  const { data: reviews, isLoading } = useListReviews(undefined, {
    query: { queryKey: getListReviewsQueryKey() },
  });

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl font-bold mb-1">Reviews</h1>
          <p className="text-muted-foreground text-sm mb-6">What our clients say</p>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : reviews && reviews.length > 0 ? (
            <div className="space-y-3">
              {reviews.map((review) => (
                <motion.div
                  key={review.id}
                  data-testid={`card-review-${review.id}`}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-card border border-card-border rounded-2xl p-4"
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold">{review.user?.name?.[0]}</span>
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{review.user?.name}</p>
                        <StarRating rating={review.rating} />
                      </div>
                    </div>
                    <div className="text-right text-xs text-muted-foreground">
                      <p>Mechanic: {review.mechanic?.name}</p>
                      <p className="text-muted-foreground/60">{review.mechanic?.specialization}</p>
                    </div>
                  </div>
                  {review.comment && (
                    <p className="text-sm text-muted-foreground mt-2">{review.comment}</p>
                  )}
                  <p className="text-xs text-muted-foreground/50 mt-2">
                    {new Date(review.createdAt).toLocaleDateString()}
                  </p>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="bg-card border border-card-border rounded-2xl p-12 text-center">
              <Star className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">No reviews yet</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Complete a service to leave a review</p>
            </div>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
