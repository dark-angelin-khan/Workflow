import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { User as UserIcon, Phone, Mail, Shield, Edit2, Check, X, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useUpdateProfile } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

export default function Profile() {
  const { user, logout, updateUser } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  useEffect(() => {
    if (!user) setLocation("/login");
    else {
      setName(user.name);
      setPhone(user.phone ?? "");
    }
  }, [user]);

  const updateMutation = useUpdateProfile({
    mutation: {
      onSuccess: (updated) => {
        updateUser(updated);
        setEditing(false);
        toast({ title: "Profile updated!" });
      },
      onError: () => toast({ title: "Failed to update profile", variant: "destructive" }),
    },
  });

  const handleSave = () => {
    updateMutation.mutate({ data: { name: name || undefined, phone: phone || null } });
  };

  const handleCancel = () => {
    setName(user?.name ?? "");
    setPhone(user?.phone ?? "");
    setEditing(false);
  };

  if (!user) return null;

  const initials = user.name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6 space-y-5">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl font-bold">Profile</h1>
          <p className="text-sm text-muted-foreground">Manage your account details</p>
        </motion.div>

        {/* Avatar */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="flex flex-col items-center gap-3 py-4">
          <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center border-2 border-primary/30">
            <span className="text-primary font-bold text-2xl">{initials}</span>
          </div>
          <div className="text-center">
            <p className="font-semibold text-lg">{user.name}</p>
            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium capitalize">{user.role}</span>
          </div>
        </motion.div>

        {/* Info Card */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card border border-card-border rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Account Info</h2>
            {!editing ? (
              <Button variant="ghost" size="sm" onClick={() => setEditing(true)} className="gap-1.5">
                <Edit2 className="h-3.5 w-3.5" /> Edit
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={handleCancel} className="gap-1 text-muted-foreground">
                  <X className="h-3.5 w-3.5" /> Cancel
                </Button>
                <Button size="sm" onClick={handleSave} disabled={updateMutation.isPending} className="gap-1">
                  <Check className="h-3.5 w-3.5" /> Save
                </Button>
              </div>
            )}
          </div>

          <div className="space-y-4">
            {/* Name */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground flex items-center gap-1.5">
                <UserIcon className="h-3 w-3" /> Full Name
              </Label>
              {editing ? (
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
              ) : (
                <p className="text-sm font-medium">{user.name}</p>
              )}
            </div>

            {/* Email (read-only) */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Mail className="h-3 w-3" /> Email
              </Label>
              <p className="text-sm font-medium text-muted-foreground">{user.email}</p>
              <p className="text-[10px] text-muted-foreground">Email cannot be changed</p>
            </div>

            {/* Phone */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Phone className="h-3 w-3" /> Phone
              </Label>
              {editing ? (
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+92 300 0000000" />
              ) : (
                <p className="text-sm font-medium">{user.phone || <span className="text-muted-foreground">Not set</span>}</p>
              )}
            </div>

            {/* Role */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Shield className="h-3 w-3" /> Role
              </Label>
              <p className="text-sm font-medium capitalize">{user.role}</p>
            </div>
          </div>
        </motion.div>

        {/* Member since */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-card border border-card-border rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Member since</p>
            <p className="text-sm font-medium mt-0.5">
              {user.createdAt ? new Date(user.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long" }) : "—"}
            </p>
          </div>
          <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
            <UserIcon className="h-5 w-5 text-muted-foreground" />
          </div>
        </motion.div>

        {/* Logout */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Button
            variant="outline"
            className="w-full border-destructive/40 text-destructive hover:bg-destructive/10"
            onClick={() => { logout(); setLocation("/"); }}
          >
            <LogOut className="h-4 w-4 mr-2" /> Sign Out
          </Button>
        </motion.div>
      </div>
    </Layout>
  );
}
