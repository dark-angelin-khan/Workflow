import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Plus, MapPin, Clock, Star, Wrench, ChevronRight, LogOut, Moon, Sun, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useGetClientDashboard, getGetClientDashboardQueryKey } from "@workspace/api-client-react";
import { useTheme } from "@/components/theme-provider";
import { Layout } from "@/components/layout";

const STATUS_LABELS: Record<string, string> = {
  searching: "Searching for mechanic",
  accepted: "Mechanic accepted",
  coming: "Mechanic on the way",
  towed: "Car towed to shop",
  diagnosing: "Diagnosing issue",
  repairing: "Repair in progress",
  ready: "Ready for delivery",
  delivered: "Delivered",
};

const STATUS_COLORS: Record<string, string> = {
  searching: "text-yellow-500",
  accepted: "text-blue-500",
  coming: "text-blue-600",
  towed: "text-purple-500",
  diagnosing: "text-orange-500",
  repairing: "text-orange-600",
  ready: "text-green-500",
  delivered: "text-green-600",
};

export default function ClientDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) setLocation("/login");
  }, [user]);

  const { data: dashboard, isLoading } = useGetClientDashboard(user?.id ?? 0, {
    query: { enabled: !!user, queryKey: getGetClientDashboardQueryKey(user?.id ?? 0) },
  });

  if (!user) return null;

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6 space-y-5">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Good day,</p>
            <h1 className="text-2xl font-bold">{user.name.split(" ")[0]}</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-primary font-bold text-sm">{user.name[0]}</span>
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 gap-3">
          <div className="bg-card border border-card-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Total Requests</p>
            <p className="text-2xl font-bold mt-1">{isLoading ? "--" : dashboard?.totalRequests ?? 0}</p>
          </div>
          <div className="bg-card border border-card-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Total Spent</p>
            <p className="text-2xl font-bold mt-1">Rs {isLoading ? "--" : (dashboard?.totalSpent ?? 0).toLocaleString()}</p>
          </div>
        </motion.div>

        {/* Active Request */}
        {dashboard?.activeRequest ? (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-2">Active Request</h2>
            <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <span className={`text-sm font-semibold ${STATUS_COLORS[dashboard.activeRequest.status] ?? "text-foreground"}`}>
                    {STATUS_LABELS[dashboard.activeRequest.status]}
                  </span>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{dashboard.activeRequest.issueDescription}</p>
                  {dashboard.activeRequest.locationAddress && (
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      {dashboard.activeRequest.locationAddress}
                    </div>
                  )}
                  {dashboard.activeRequest.estimatedArrival && (
                    <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      ETA: {dashboard.activeRequest.estimatedArrival}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button size="sm" className="flex-1" asChild>
                  <Link href={`/tracking/${dashboard.activeRequest.id}`}>Track</Link>
                </Button>
                <Button size="sm" variant="outline" className="flex-1" asChild>
                  <Link href={`/chat/${dashboard.activeRequest.id}`}>
                    <MessageSquare className="h-4 w-4 mr-1" /> Chat
                  </Link>
                </Button>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <Link href="/request-service">
              <div className="bg-primary rounded-2xl p-5 flex items-center justify-between cursor-pointer hover:bg-primary/90 transition-colors">
                <div>
                  <h2 className="text-primary-foreground font-bold text-lg">Need Help?</h2>
                  <p className="text-primary-foreground/80 text-sm mt-0.5">Request a mechanic now</p>
                </div>
                <div className="w-12 h-12 rounded-xl bg-primary-foreground/20 flex items-center justify-center">
                  <Plus className="h-6 w-6 text-primary-foreground" />
                </div>
              </div>
            </Link>
          </motion.div>
        )}

        {/* Recent */}
        {dashboard?.recentRequests && dashboard.recentRequests.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-2">Recent Requests</h2>
            <div className="space-y-2">
              {dashboard.recentRequests.map((req) => (
                <div key={req.id} data-testid={`card-request-${req.id}`} className="bg-card border border-card-border rounded-xl p-4 flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{req.issueDescription}</p>
                    <p className={`text-xs mt-0.5 ${STATUS_COLORS[req.status] ?? "text-muted-foreground"}`}>
                      {STATUS_LABELS[req.status]}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 ml-3">
                    {req.estimatedCost && (
                      <span className="text-xs text-muted-foreground">Rs {req.estimatedCost.toLocaleString()}</span>
                    )}
                    {req.status === "delivered" && (
                      <Link href={`/rate/${req.id}`}>
                        <Button size="sm" variant="outline" className="text-xs px-2 py-1 h-auto">
                          <Star className="h-3 w-3 mr-1" /> Rate
                        </Button>
                      </Link>
                    )}
                    {["searching","accepted","coming","towed","diagnosing","repairing"].includes(req.status) && (
                      <Link href={`/tracking/${req.id}`}>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </Link>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </Layout>
  );
}
