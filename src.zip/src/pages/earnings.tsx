import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { DollarSign, Clock, CheckCircle, XCircle, ChevronLeft, Loader, ArrowDownToLine, Smartphone, Landmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import {
  useListMechanics,
  getListMechanicsQueryKey,
  useGetMechanicDashboard,
  getGetMechanicDashboardQueryKey,
  useListWithdrawals,
  getListWithdrawalsQueryKey,
  useRequestWithdrawal,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

type WithdrawMethod = "easypaisa" | "jazzcash" | "bank";

const METHODS: { id: WithdrawMethod; label: string; placeholder: string; icon: React.ReactNode; color: string }[] = [
  {
    id: "easypaisa",
    label: "EasyPaisa",
    placeholder: "03XX-XXXXXXX",
    icon: <span className="text-sm font-bold">EP</span>,
    color: "bg-emerald-500/10 border-emerald-500/40 text-emerald-500",
  },
  {
    id: "jazzcash",
    label: "JazzCash",
    placeholder: "03XX-XXXXXXX",
    icon: <span className="text-sm font-bold">JC</span>,
    color: "bg-red-500/10 border-red-500/40 text-red-500",
  },
  {
    id: "bank",
    label: "Bank Transfer",
    placeholder: "IBAN or Account No.",
    icon: <Landmark className="h-4 w-4" />,
    color: "bg-blue-500/10 border-blue-500/40 text-blue-500",
  },
];

const STATUS_CONFIG: Record<string, { label: string; icon: React.ReactNode; cls: string }> = {
  pending: {
    label: "Pending",
    icon: <Clock className="h-3.5 w-3.5" />,
    cls: "bg-yellow-500/10 text-yellow-500 border-yellow-500/30",
  },
  completed: {
    label: "Completed",
    icon: <CheckCircle className="h-3.5 w-3.5" />,
    cls: "bg-green-500/10 text-green-500 border-green-500/30",
  },
  rejected: {
    label: "Rejected",
    icon: <XCircle className="h-3.5 w-3.5" />,
    cls: "bg-destructive/10 text-destructive border-destructive/30",
  },
};

export default function Earnings() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [showForm, setShowForm] = useState(false);
  const [method, setMethod] = useState<WithdrawMethod>("easypaisa");
  const [accountNumber, setAccountNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");

  useEffect(() => {
    if (!user || user.role !== "mechanic") setLocation("/login");
  }, [user]);

  const { data: mechanics } = useListMechanics({
    query: { enabled: !!user, queryKey: getListMechanicsQueryKey() },
  });
  const myMechanic = mechanics?.find((m) => m.userId === user?.id);

  const { data: dashboard, isLoading: dashLoading } = useGetMechanicDashboard(myMechanic?.id ?? 0, {
    query: {
      enabled: !!myMechanic?.id,
      queryKey: getGetMechanicDashboardQueryKey(myMechanic?.id ?? 0),
    },
  });

  const { data: withdrawals, isLoading: wLoading } = useListWithdrawals(myMechanic?.id ?? 0, {
    query: {
      enabled: !!myMechanic?.id,
      queryKey: getListWithdrawalsQueryKey(myMechanic?.id ?? 0),
    },
  });

  const withdrawMutation = useRequestWithdrawal({
    mutation: {
      onSuccess: () => {
        toast({ title: "Withdrawal requested!", description: "We'll process it within 24 hours." });
        queryClient.invalidateQueries({ queryKey: getListWithdrawalsQueryKey(myMechanic?.id ?? 0) });
        setShowForm(false);
        setAmount("");
        setAccountNumber("");
        setNote("");
      },
      onError: (err: Error) => {
        toast({ title: "Request failed", description: err.message, variant: "destructive" });
      },
    },
  });

  if (!user || user.role !== "mechanic") return null;

  const totalEarned = dashboard?.totalEarnings ?? 0;
  const totalWithdrawn = withdrawals
    ? withdrawals.filter((w) => w.status !== "rejected").reduce((s, w) => s + w.amount, 0)
    : 0;
  const available = Math.max(0, totalEarned - totalWithdrawn);

  const selectedMethod = METHODS.find((m) => m.id === method)!;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(amount);
    if (!amountNum || !accountNumber.trim() || !myMechanic) return;
    withdrawMutation.mutate({
      mechanicId: myMechanic.id,
      data: { amount: amountNum, method, accountNumber: accountNumber.trim(), note: note || null },
    });
  };

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6 space-y-5">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
          <button onClick={() => setLocation("/mechanic-dashboard")} className="text-muted-foreground">
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">Earnings</h1>
            <p className="text-sm text-muted-foreground">Track your income & payouts</p>
          </div>
        </motion.div>

        {/* Balance Cards */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}>
          {/* Available balance — hero */}
          <div className="bg-primary rounded-2xl p-6 mb-3 relative overflow-hidden">
            <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-primary-foreground/5" />
            <div className="absolute -right-2 bottom-2 w-20 h-20 rounded-full bg-primary-foreground/5" />
            <p className="text-primary-foreground/70 text-sm mb-1">Available to Withdraw</p>
            <p className="text-4xl font-bold text-primary-foreground">
              Rs {dashLoading ? "—" : available.toLocaleString()}
            </p>
            <Button
              data-testid="button-withdraw"
              size="sm"
              variant="secondary"
              className="mt-4"
              disabled={available <= 0}
              onClick={() => setShowForm(true)}
            >
              <ArrowDownToLine className="h-4 w-4 mr-2" />
              Withdraw Now
            </Button>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-card border border-card-border rounded-2xl p-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Total Earned</p>
              <p className="text-xl font-bold">Rs {dashLoading ? "—" : totalEarned.toLocaleString()}</p>
            </div>
            <div className="bg-card border border-card-border rounded-2xl p-4">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Total Withdrawn</p>
              <p className="text-xl font-bold">Rs {wLoading ? "—" : totalWithdrawn.toLocaleString()}</p>
            </div>
          </div>
        </motion.div>

        {/* Withdrawal form */}
        <AnimatePresence>
          {showForm && (
            <motion.div
              initial={{ opacity: 0, height: 0, y: -8 }}
              animate={{ opacity: 1, height: "auto", y: 0 }}
              exit={{ opacity: 0, height: 0, y: -8 }}
              className="overflow-hidden"
            >
              <div className="bg-card border border-card-border rounded-2xl p-5">
                <h2 className="font-semibold mb-4">New Withdrawal Request</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Method selector */}
                  <div>
                    <Label className="mb-2 block">Payment Method</Label>
                    <div className="grid grid-cols-3 gap-2">
                      {METHODS.map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          data-testid={`button-method-${m.id}`}
                          onClick={() => { setMethod(m.id); setAccountNumber(""); }}
                          className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border-2 text-xs font-medium transition-all ${
                            method === m.id ? m.color + " border-current" : "border-border text-muted-foreground"
                          }`}
                        >
                          {m.icon}
                          {m.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Account number */}
                  <div className="space-y-2">
                    <Label htmlFor="account">Account Number</Label>
                    <div className="relative">
                      <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="account"
                        data-testid="input-account"
                        className="pl-9"
                        placeholder={selectedMethod.placeholder}
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {/* Amount */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="amount">Amount (Rs)</Label>
                      <button
                        type="button"
                        className="text-xs text-primary font-medium"
                        onClick={() => setAmount(String(Math.floor(available)))}
                      >
                        Max: Rs {available.toLocaleString()}
                      </button>
                    </div>
                    <Input
                      id="amount"
                      data-testid="input-amount"
                      type="number"
                      placeholder="e.g. 5000"
                      min={100}
                      max={available}
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      required
                    />
                  </div>

                  {/* Note */}
                  <div className="space-y-2">
                    <Label htmlFor="note">Note (optional)</Label>
                    <Input
                      id="note"
                      data-testid="input-note"
                      placeholder="Any message for admin"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                    />
                  </div>

                  <div className="flex gap-2 pt-1">
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={() => setShowForm(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      data-testid="button-submit-withdrawal"
                      type="submit"
                      className="flex-1"
                      disabled={withdrawMutation.isPending || !amount || !accountNumber}
                    >
                      {withdrawMutation.isPending ? "Requesting…" : "Request Payout"}
                    </Button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Payout history */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Payout History</h2>
          {wLoading ? (
            <div className="flex justify-center py-8">
              <Loader className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : withdrawals && withdrawals.length > 0 ? (
            <div className="space-y-2">
              {withdrawals.map((w) => {
                const cfg = STATUS_CONFIG[w.status] ?? STATUS_CONFIG.pending;
                const mCfg = METHODS.find((m) => m.id === w.method);
                return (
                  <motion.div
                    key={w.id}
                    data-testid={`card-withdrawal-${w.id}`}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-card border border-card-border rounded-2xl p-4 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 ${mCfg?.color ?? "bg-muted"}`}>
                        {mCfg?.icon}
                      </div>
                      <div>
                        <p className="text-sm font-semibold">Rs {w.amount.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground capitalize">{mCfg?.label ?? w.method} · {w.accountNumber}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(w.requestedAt).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}
                        </p>
                      </div>
                    </div>
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full border text-xs font-medium ${cfg.cls}`}>
                      {cfg.icon}
                      {cfg.label}
                    </span>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="bg-card border border-card-border rounded-2xl p-10 text-center">
              <DollarSign className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No payouts yet</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Your withdrawal history will appear here</p>
            </div>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
