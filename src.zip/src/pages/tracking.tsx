import { useEffect } from "react";
import { Link, useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { MapPin, Clock, Phone, MessageSquare, Star, ChevronLeft, CheckCircle, Circle, Loader, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useGetServiceRequest, getGetServiceRequestQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";

const STAGES = [
  { key: "searching", label: "Searching Mechanic", desc: "Finding the nearest available mechanic" },
  { key: "accepted", label: "Mechanic Accepted", desc: "A mechanic has accepted your request" },
  { key: "coming", label: "Mechanic Coming", desc: "Your mechanic is on the way" },
  { key: "towed", label: "Car Towed to Shop", desc: "Your car is being taken to the workshop" },
  { key: "diagnosing", label: "Diagnosing Issue", desc: "Mechanic is inspecting your vehicle" },
  { key: "repairing", label: "Repair in Progress", desc: "Your car is being repaired" },
  { key: "ready", label: "Ready for Delivery", desc: "Your car is ready to be picked up" },
  { key: "delivered", label: "Delivered", desc: "Your car has been delivered" },
];

export default function Tracking() {
  const { id } = useParams();
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) setLocation("/login");
  }, [user]);

  const requestId = parseInt(id ?? "0");
  const { data: request, isLoading } = useGetServiceRequest(requestId, {
    query: { enabled: !!requestId, queryKey: getGetServiceRequestQueryKey(requestId), refetchInterval: 5000 },
  });

  if (!user) return null;

  const currentStageIndex = STAGES.findIndex((s) => s.key === request?.status);

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6">
        <button onClick={() => setLocation("/client-dashboard")} className="flex items-center gap-1 text-sm text-muted-foreground mb-5">
          <ChevronLeft className="h-4 w-4" /> Dashboard
        </button>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl font-bold mb-1">Live Tracking</h1>
          <p className="text-sm text-muted-foreground mb-6">Request #{id}</p>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : request ? (
            <>
              {/* Mechanic Card */}
              {request.mechanic && (
                <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} className="bg-card border border-card-border rounded-2xl p-4 mb-5">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide mb-3">Your Mechanic</p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-primary font-bold">{request.mechanic.name[0]}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold">{request.mechanic.name}</p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        {request.mechanic.rating.toFixed(1)} &bull; {request.mechanic.totalJobs} jobs
                      </div>
                      <p className="text-xs text-muted-foreground">{request.mechanic.specialization}</p>
                    </div>
                    <div className="flex gap-2">
                      {request.mechanic.phone && (
                        <a href={`tel:${request.mechanic.phone}`}>
                          <Button size="icon" variant="outline" className="h-9 w-9">
                            <Phone className="h-4 w-4" />
                          </Button>
                        </a>
                      )}
                      <Button size="icon" variant="outline" className="h-9 w-9" asChild>
                        <Link href={`/chat/${request.id}`}>
                          <MessageSquare className="h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                  {request.estimatedArrival && (
                    <div className="mt-3 flex items-center gap-2 bg-primary/10 rounded-lg px-3 py-2">
                      <Clock className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium text-primary">ETA: {request.estimatedArrival}</span>
                    </div>
                  )}
                </motion.div>
              )}

              {/* Status Timeline */}
              <div className="bg-card border border-card-border rounded-2xl p-4 mb-5">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-4">Service Progress</p>
                <div className="space-y-0">
                  {STAGES.map((stage, i) => {
                    const isDone = i < currentStageIndex;
                    const isActive = i === currentStageIndex;
                    return (
                      <div key={stage.key} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${isDone ? "bg-green-500" : isActive ? "bg-primary" : "bg-muted"}`}>
                            {isDone ? (
                              <CheckCircle className="h-4 w-4 text-white" />
                            ) : isActive ? (
                              <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1.5 }}>
                                <Circle className="h-3 w-3 text-white fill-white" />
                              </motion.div>
                            ) : (
                              <Circle className="h-3 w-3 text-muted-foreground" />
                            )}
                          </div>
                          {i < STAGES.length - 1 && (
                            <div className={`w-0.5 h-8 mt-0.5 ${isDone ? "bg-green-500" : "bg-border"}`} />
                          )}
                        </div>
                        <div className={`pb-4 pt-0.5 ${i === STAGES.length - 1 ? "pb-0" : ""}`}>
                          <p className={`text-sm font-medium ${isActive ? "text-primary" : isDone ? "text-foreground" : "text-muted-foreground"}`}>
                            {stage.label}
                          </p>
                          {isActive && (
                            <p className="text-xs text-muted-foreground mt-0.5">{stage.desc}</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Cost Estimation */}
              {request.estimatedCost && (
                <div className="bg-card border border-card-border rounded-2xl p-4 mb-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide">Estimated Cost</p>
                      <p className="text-2xl font-bold mt-1">Rs {request.estimatedCost.toLocaleString()}</p>
                    </div>
                    {request.diagnosisItems && (
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Diagnosis items</p>
                        {(() => {
                          try {
                            const items = JSON.parse(request.diagnosisItems);
                            return items.map((item: { name: string; price: number }) => (
                              <p key={item.name} className="text-xs mt-0.5">{item.name}: Rs {item.price.toLocaleString()}</p>
                            ));
                          } catch { return null; }
                        })()}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Location */}
              {request.locationAddress && (
                <div className="bg-muted/50 rounded-xl p-4 flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-primary flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground">Service Location</p>
                    <p className="text-sm font-medium">{request.locationAddress}</p>
                  </div>
                </div>
              )}

              {/* Payment CTA */}
              {(request.status === "ready" || request.status === "delivered") && request.paymentStatus !== "paid" && request.estimatedCost && (
                <div className="mt-4">
                  <Button size="lg" className="w-full" asChild>
                    <Link href={`/payment/${request.id}`}>
                      <CreditCard className="mr-2 h-4 w-4" />
                      Pay Rs {request.estimatedCost.toLocaleString()}
                    </Link>
                  </Button>
                </div>
              )}

              {/* Paid badge */}
              {request.paymentStatus === "paid" && (
                <div className="mt-4 bg-green-500/10 border border-green-500/30 rounded-xl px-4 py-3 flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-green-600 dark:text-green-400">Payment Complete</p>
                    <p className="text-xs text-muted-foreground capitalize">Paid via {request.paymentMethod}</p>
                  </div>
                </div>
              )}

              {request.status === "delivered" && request.paymentStatus === "paid" && (
                <div className="mt-3">
                  <Button variant="outline" className="w-full" asChild>
                    <Link href={`/rate/${request.id}`}>
                      <Star className="mr-2 h-4 w-4" /> Rate this service
                    </Link>
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-12 text-muted-foreground">Request not found</div>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
