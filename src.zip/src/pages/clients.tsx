import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Users, Phone, Mail, Bookmark, BookmarkCheck, Trash2, Loader, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useGetMechanicClients, useListMechanics, getListMechanicsQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { useToast } from "@/hooks/use-toast";

const SAVED_KEY = "mechconnect_saved_clients";
const DELETED_KEY = "mechconnect_deleted_clients";

function getSavedIds(): number[] {
  try { return JSON.parse(localStorage.getItem(SAVED_KEY) ?? "[]"); } catch { return []; }
}
function getDeletedIds(): number[] {
  try { return JSON.parse(localStorage.getItem(DELETED_KEY) ?? "[]"); } catch { return []; }
}
function setSavedIds(ids: number[]) { localStorage.setItem(SAVED_KEY, JSON.stringify(ids)); }
function setDeletedIds(ids: number[]) { localStorage.setItem(DELETED_KEY, JSON.stringify(ids)); }

export default function Clients() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [savedIds, setSaved] = useState<number[]>(getSavedIds);
  const [deletedIds, setDeleted] = useState<number[]>(getDeletedIds);
  const [tab, setTab] = useState<"all" | "saved">("all");

  useEffect(() => {
    if (!user) setLocation("/login");
    if (user && user.role !== "mechanic") setLocation("/client-dashboard");
  }, [user]);

  const { data: mechanics } = useListMechanics({ query: { queryKey: getListMechanicsQueryKey() } });
  const myMechanic = mechanics?.find((m) => m.userId === user?.id);

  const { data: clients, isLoading } = useGetMechanicClients(myMechanic?.id ?? 0, {
    query: { enabled: !!myMechanic?.id },
  });

  const visibleClients = (clients ?? [])
    .filter((c) => !deletedIds.includes(c.userId))
    .filter((c) => tab === "saved" ? savedIds.includes(c.userId) : true);

  const toggleSave = (userId: number) => {
    const isSaved = savedIds.includes(userId);
    const updated = isSaved ? savedIds.filter((id) => id !== userId) : [...savedIds, userId];
    setSaved(updated);
    setSavedIds(updated);
    toast({ title: isSaved ? "Removed from saved" : "Client saved!" });
  };

  const deleteClient = (userId: number) => {
    const updated = [...deletedIds, userId];
    setDeleted(updated);
    setDeletedIds(updated);
    const newSaved = savedIds.filter((id) => id !== userId);
    setSaved(newSaved);
    setSavedIds(newSaved);
    toast({ title: "Client removed from list" });
  };

  if (!user || user.role !== "mechanic") return null;

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6 space-y-5">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl font-bold">My Clients</h1>
          <p className="text-sm text-muted-foreground">Manage your past clients</p>
        </motion.div>

        {/* Tabs */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="flex gap-2">
          <button
            onClick={() => setTab("all")}
            className={`flex-1 py-2 rounded-xl text-sm font-medium transition-colors ${tab === "all" ? "bg-primary text-primary-foreground" : "bg-card border border-card-border text-muted-foreground hover:text-foreground"}`}
          >
            All Clients
          </button>
          <button
            onClick={() => setTab("saved")}
            className={`flex-1 py-2 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-1.5 ${tab === "saved" ? "bg-primary text-primary-foreground" : "bg-card border border-card-border text-muted-foreground hover:text-foreground"}`}
          >
            <BookmarkCheck className="h-3.5 w-3.5" /> Saved
            {savedIds.length > 0 && (
              <span className={`ml-1 px-1.5 rounded-full text-[10px] font-bold ${tab === "saved" ? "bg-primary-foreground/20 text-primary-foreground" : "bg-primary/10 text-primary"}`}>
                {savedIds.length}
              </span>
            )}
          </button>
        </motion.div>

        {/* Client List */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : visibleClients.length === 0 ? (
            <div className="bg-card border border-card-border rounded-2xl p-8 text-center">
              <Users className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground text-sm">
                {tab === "saved" ? "No saved clients yet" : "No clients found"}
              </p>
              {tab === "saved" && (
                <p className="text-xs text-muted-foreground mt-1">Bookmark a client from the All Clients tab</p>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {visibleClients.map((client, i) => {
                const isSaved = savedIds.includes(client.userId);
                const initials = client.name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2);
                return (
                  <motion.div
                    key={client.userId}
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.04 }}
                    className="bg-card border border-card-border rounded-2xl p-4"
                  >
                    <div className="flex items-start gap-3">
                      {/* Avatar */}
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-primary font-bold text-sm">{initials}</span>
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-semibold text-sm truncate">{client.name}</p>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <Button
                              variant="ghost"
                              size="icon"
                              className={`h-7 w-7 ${isSaved ? "text-primary" : "text-muted-foreground"}`}
                              onClick={() => toggleSave(client.userId)}
                              title={isSaved ? "Unsave" : "Save client"}
                            >
                              {isSaved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-muted-foreground hover:text-destructive"
                              onClick={() => deleteClient(client.userId)}
                              title="Remove client"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        {client.email && (
                          <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                            <Mail className="h-3 w-3" />
                            <span className="truncate">{client.email}</span>
                          </div>
                        )}
                        {client.phone && (
                          <div className="flex items-center gap-1 mt-0.5 text-xs text-muted-foreground">
                            <Phone className="h-3 w-3" />
                            <span>{client.phone}</span>
                          </div>
                        )}

                        <div className="flex items-center gap-3 mt-2">
                          <span className="text-xs bg-muted px-2 py-0.5 rounded-full font-medium">
                            {client.totalJobs} {client.totalJobs === 1 ? "job" : "jobs"}
                          </span>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {new Date(client.lastServiceAt).toLocaleDateString("en-US", {
                              month: "short",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
