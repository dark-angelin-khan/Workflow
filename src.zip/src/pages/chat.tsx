import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Send, ChevronLeft, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import {
  useListMessages,
  getListMessagesQueryKey,
  useSendMessage,
  useGetServiceRequest,
  getGetServiceRequestQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export default function Chat() {
  const { id } = useParams();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [message, setMessage] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!user) setLocation("/login");
  }, [user]);

  const requestId = parseInt(id ?? "0");

  const { data: request } = useGetServiceRequest(requestId, {
    query: { enabled: !!requestId, queryKey: getGetServiceRequestQueryKey(requestId) },
  });

  const { data: messages, isLoading } = useListMessages(requestId, {
    query: {
      enabled: !!requestId,
      queryKey: getListMessagesQueryKey(requestId),
      refetchInterval: 3000,
    },
  });

  const sendMutation = useSendMessage({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey(requestId) });
        setMessage("");
      },
    },
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (!user) return null;

  const otherPerson = user.role === "client" ? request?.mechanic?.name : request?.user?.name;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !user) return;
    sendMutation.mutate({
      requestId,
      data: { senderId: user.id, content: message.trim() },
    });
  };

  return (
    <div className="flex flex-col h-[100dvh] bg-background">
      {/* Header */}
      <div className="sticky top-0 z-50 flex items-center gap-3 px-4 py-3 border-b bg-background/95 backdrop-blur">
        <button onClick={() => setLocation(user.role === "mechanic" ? "/mechanic-dashboard" : "/client-dashboard")}>
          <ChevronLeft className="h-5 w-5 text-muted-foreground" />
        </button>
        {otherPerson && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-primary font-bold text-xs">{otherPerson[0]}</span>
            </div>
            <div>
              <p className="text-sm font-semibold">{otherPerson}</p>
              <p className="text-xs text-green-500">Online</p>
            </div>
          </div>
        )}
        {!otherPerson && <p className="font-semibold">Chat</p>}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : messages && messages.length > 0 ? (
          messages.map((msg) => {
            const isMe = msg.senderId === user.id;
            return (
              <motion.div
                key={msg.id}
                data-testid={`message-${msg.id}`}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${isMe ? "justify-end" : "justify-start"}`}
              >
                <div className={`max-w-[75%] ${isMe ? "items-end" : "items-start"} flex flex-col`}>
                  <div
                    className={`px-4 py-2.5 rounded-2xl text-sm ${
                      isMe
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-card border border-card-border text-card-foreground rounded-bl-sm"
                    }`}
                  >
                    {msg.content}
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1 px-1">
                    {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </motion.div>
            );
          })
        ) : (
          <div className="text-center py-12 text-muted-foreground text-sm">
            No messages yet. Start the conversation!
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="sticky bottom-0 px-4 py-3 border-t bg-background pb-safe">
        <form onSubmit={handleSend} className="flex gap-2">
          <Input
            data-testid="input-message"
            placeholder="Type a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-1"
          />
          <Button
            data-testid="button-send"
            type="submit"
            size="icon"
            disabled={!message.trim() || sendMutation.isPending}
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
