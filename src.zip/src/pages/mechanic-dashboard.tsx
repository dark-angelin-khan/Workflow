import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Star, Briefcase, DollarSign, Clock, CheckCircle, XCircle, ChevronRight, MessageSquare, Loader, ArrowDownToLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import {
  useGetMechanicDashboard,
  getGetMechanicDashboardQueryKey,
  useListMechanics,
  getListMechanicsQueryKey,
  useAcceptServiceRequest,
  getGetMechanicDashboardQueryKey as mechDashKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

export default function MechanicDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!user) setLocation("/login");
    if (user && user.role !== "mechanic") setLocation("/client-dashboard");
  }, [user]);

  const { data: mechanics } = useListMechanics({ query: { queryKey: getListMechanicsQueryKey() } });
  const myMechanic = mechanics?.find((m) => m.userId === user?.id);

  const { data: dashboard, isLoading } = useGetMechanicDashboard(myMechanic?.id ?? 0, {
    query: {
      enabled: !!myMechanic?.id,
      queryKey: getGetMechanicDashboardQueryKey(myMechanic?.id ?? 0),
      refetchInterval: 5000,
    },
  });

  const acceptMutation = useAcceptServiceRequest({
    mutation: {
      onSuccess: () => {
        toast({ title: "Request accepted!" });
        queryClient.invalidateQueries({ queryKey: mechDashKey(myMechanic?.id ?? 0) });
      },
      onError: () => toast({ title: "Failed to accept", variant: "destructive" }),
    },
  });

  if (!user || user.role !== "mechanic") return null;

  return (
    <Layout>
      <div className="max-w-lg mx-auto px-4 py-6 space-y-5">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Mechanic Portal</p>
            <h1 className="text-2xl font-bold">{user.name.split(" ")[0]}</h1>
          </div>
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
            <span className="text-primary font-bold">{user.name[0]}</span>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 gap-3">
          <div className="bg-card border border-card-border rounded-2xl p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-xs">Rating</span>
            </div>
            <p className="text-2xl font-bold">{dashboard?.rating.toFixed(1) ?? myMechanic?.rating.toFixed(1) ?? "5.0"}</p>
          </div>
          <div className="bg-card border border-card-border rounded-2xl p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Briefcase className="h-4 w-4" />
              <span className="text-xs">Today</span>
            </div>
            <p className="text-2xl font-bold">{isLoading ? "--" : dashboard?.completedToday ?? 0}</p>
          </div>
          <Link href="/earnings" className="col-span-2 block">
            <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4 flex items-center justify-between hover:bg-primary/15 transition-colors">
              <div>
                <div className="flex items-center gap-2 text-muted-foreground mb-1">
                  <DollarSign className="h-4 w-4 text-primary" />
                  <span className="text-xs">Total Earnings</span>
                </div>
                <p className="text-2xl font-bold">Rs {isLoading ? "--" : (dashboard?.totalEarnings ?? 0).toLocaleString()}</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-xs text-primary font-medium flex items-center gap-1">
                  <ArrowDownToLine className="h-3.5 w-3.5" /> Withdraw
                </span>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </Link>
        </motion.div>

        {/* Active Jobs */}
        {dashboard?.activeRequests && dashboard.activeRequests.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-2">Active Jobs</h2>
            <div className="space-y-2">
              {dashboard.activeRequests.map((req) => (
                <div key={req.id} data-testid={`card-active-${req.id}`} className="bg-primary/10 border border-primary/20 rounded-xl p-4 flex items-center justify-between">
                  <Link href={`/mechanic-request/${req.id}`} className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{req.issueDescription}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{req.user?.name} &bull; {req.locationAddress}</p>
                    <p className="text-xs text-primary mt-0.5 capitalize">{req.status.replace("_", " ")}</p>
                  </Link>
                  <div className="flex items-center gap-2 ml-3">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/chat/${req.id}`}>
                        <MessageSquare className="h-4 w-4" />
                      </Link>
                    </Button>
                    <Link href={`/mechanic-request/${req.id}`}>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Pending Requests */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-2">
            Incoming Requests {dashboard?.pendingRequests?.length ? `(${dashboard.pendingRequests.length})` : ""}
          </h2>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : dashboard?.pendingRequests && dashboard.pendingRequests.length > 0 ? (
            <div className="space-y-3">
              {dashboard.pendingRequests.map((req) => (
                <motion.div
                  key={req.id}
                  data-testid={`card-pending-${req.id}`}
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-card border border-card-border rounded-2xl p-4"
                >
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center">
                          <span className="text-xs font-bold">{req.user?.name?.[0]}</span>
                        </div>
                        <span className="text-sm font-medium">{req.user?.name}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{req.issueDescription}</p>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground flex-shrink-0">
                      <Clock className="h-3 w-3" />
                      {new Date(req.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </div>
                  </div>
                  {req.locationAddress && (
                    <p className="text-xs text-muted-foreground mb-3">Location: {req.locationAddress}</p>
                  )}
                  <div className="flex gap-2">
                    <Button
                      data-testid={`button-accept-${req.id}`}
                      size="sm"
                      className="flex-1"
                      disabled={acceptMutation.isPending}
                      onClick={() =>
                        acceptMutation.mutate({
                          id: req.id,
                          data: { mechanicId: myMechanic?.id ?? 0, estimatedArrival: "15-20 min" },
                        })
                      }
                    >
                      <CheckCircle className="h-4 w-4 mr-1" /> Accept
                    </Button>
                    <Button data-testid={`button-reject-${req.id}`} size="sm" variant="outline" className="flex-1 text-destructive">
                      <XCircle className="h-4 w-4 mr-1" /> Reject
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="bg-card border border-card-border rounded-2xl p-8 text-center">
              <Briefcase className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground text-sm">No incoming requests right now</p>
            </div>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
