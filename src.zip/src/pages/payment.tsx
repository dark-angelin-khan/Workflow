import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, Loader, CheckCircle, CreditCard, Banknote, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import {
  useGetServiceRequest,
  getGetServiceRequestQueryKey,
  useSubmitPayment,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/layout";

type PaymentMethod = "cash" | "easypaisa" | "jazzcash" | "card";

const PAYMENT_METHODS: {
  id: PaymentMethod;
  label: string;
  icon: React.ReactNode;
  color: string;
  accent: string;
  desc: string;
  showAccount?: boolean;
}[] = [
  {
    id: "cash",
    label: "Cash",
    icon: <Banknote className="h-6 w-6" />,
    color: "bg-green-500/10 border-green-500/30",
    accent: "text-green-500",
    desc: "Pay in cash to the mechanic on delivery",
  },
  {
    id: "easypaisa",
    label: "EasyPaisa",
    icon: (
      <span className="text-lg font-bold leading-none">EP</span>
    ),
    color: "bg-emerald-500/10 border-emerald-500/30",
    accent: "text-emerald-500",
    desc: "Send to EasyPaisa account provided by mechanic",
    showAccount: true,
  },
  {
    id: "jazzcash",
    label: "JazzCash",
    icon: (
      <span className="text-lg font-bold leading-none">JC</span>
    ),
    color: "bg-red-500/10 border-red-500/30",
    accent: "text-red-500",
    desc: "Send to JazzCash account provided by mechanic",
    showAccount: true,
  },
  {
    id: "card",
    label: "Debit / Credit Card",
    icon: <CreditCard className="h-6 w-6" />,
    color: "bg-blue-500/10 border-blue-500/30",
    accent: "text-blue-500",
    desc: "Securely pay with your bank card",
    showAccount: false,
  },
];

const MOCK_ACCOUNT: Record<string, string> = {
  easypaisa: "0300-1234567",
  jazzcash: "0312-9876543",
};

export default function Payment() {
  const { id } = useParams();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selected, setSelected] = useState<PaymentMethod | null>(null);
  const [transactionId, setTransactionId] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!user) setLocation("/login");
  }, [user]);

  const requestId = parseInt(id ?? "0");
  const { data: request, isLoading } = useGetServiceRequest(requestId, {
    query: { enabled: !!requestId, queryKey: getGetServiceRequestQueryKey(requestId) },
  });

  const payMutation = useSubmitPayment({
    mutation: {
      onSuccess: (data) => {
        setSuccess(true);
        queryClient.invalidateQueries({ queryKey: getGetServiceRequestQueryKey(requestId) });
        toast({ title: "Payment successful!", description: `Paid via ${selected}` });
        setTimeout(() => {
          setLocation(data.status === "delivered" ? `/rate/${requestId}` : `/tracking/${requestId}`);
        }, 2500);
      },
      onError: () => toast({ title: "Payment failed", description: "Please try again", variant: "destructive" }),
    },
  });

  if (!user) return null;

  const method = PAYMENT_METHODS.find((m) => m.id === selected);
  const canPay =
    selected &&
    (selected === "cash" ||
      (selected === "card" && cardNumber.length >= 16 && cardExpiry && cardCvv) ||
      ((selected === "easypaisa" || selected === "jazzcash") && transactionId.length >= 6));

  const handlePay = () => {
    if (!selected) return;
    payMutation.mutate({
      id: requestId,
      data: {
        method: selected,
        transactionId: transactionId || null,
        accountNumber: null,
      },
    });
  };

  return (
    <Layout>
      <div className="max-w-sm mx-auto px-4 py-6">
        <button onClick={() => setLocation(`/tracking/${requestId}`)} className="flex items-center gap-1 text-sm text-muted-foreground mb-5">
          <ChevronLeft className="h-4 w-4" /> Back
        </button>

        <AnimatePresence mode="wait">
          {success ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-12"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-5"
              >
                <CheckCircle className="h-10 w-10 text-green-500" />
              </motion.div>
              <h2 className="text-2xl font-bold">Payment Successful!</h2>
              <p className="text-muted-foreground mt-2 text-sm">
                {selected === "cash" ? "Cash payment confirmed." : "Transaction recorded."}
                <br />Redirecting you now…
              </p>
            </motion.div>
          ) : (
            <motion.div key="form" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
              <h1 className="text-2xl font-bold mb-1">Payment</h1>
              <p className="text-muted-foreground text-sm mb-6">Choose how you'd like to pay</p>

              {isLoading ? (
                <div className="flex justify-center py-8"><Loader className="h-8 w-8 animate-spin text-primary" /></div>
              ) : request ? (
                <>
                  {/* Amount card */}
                  <div className="bg-primary rounded-2xl p-5 mb-6 text-center">
                    <p className="text-primary-foreground/70 text-sm mb-1">Amount Due</p>
                    <p className="text-4xl font-bold text-primary-foreground">
                      Rs {(request.estimatedCost ?? 0).toLocaleString()}
                    </p>
                    <p className="text-primary-foreground/60 text-xs mt-2">
                      {request.issueDescription}
                    </p>
                  </div>

                  {/* Already paid */}
                  {request.paymentStatus === "paid" ? (
                    <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-5 text-center">
                      <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                      <p className="font-semibold text-green-600 dark:text-green-400">Already Paid</p>
                      <p className="text-sm text-muted-foreground mt-1 capitalize">
                        via {request.paymentMethod} · {request.paidAt ? new Date(request.paidAt).toLocaleDateString() : ""}
                      </p>
                    </div>
                  ) : (
                    <>
                      {/* Method selection */}
                      <div className="space-y-3 mb-6">
                        {PAYMENT_METHODS.map((pm) => (
                          <button
                            key={pm.id}
                            data-testid={`button-method-${pm.id}`}
                            onClick={() => { setSelected(pm.id); setTransactionId(""); setCardNumber(""); setCardExpiry(""); setCardCvv(""); }}
                            className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all ${
                              selected === pm.id
                                ? `${pm.color} border-current`
                                : "border-border bg-card hover:border-primary/40"
                            }`}
                          >
                            <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${selected === pm.id ? pm.color : "bg-muted"}`}>
                              <span className={selected === pm.id ? pm.accent : "text-muted-foreground"}>{pm.icon}</span>
                            </div>
                            <div className="flex-1">
                              <p className={`font-semibold text-sm ${selected === pm.id ? pm.accent : ""}`}>{pm.label}</p>
                              <p className="text-xs text-muted-foreground mt-0.5">{pm.desc}</p>
                            </div>
                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${selected === pm.id ? "border-current " + pm.accent : "border-border"}`}>
                              {selected === pm.id && <div className={`w-2.5 h-2.5 rounded-full ${pm.accent.replace("text-", "bg-")}`} />}
                            </div>
                          </button>
                        ))}
                      </div>

                      {/* Dynamic detail inputs */}
                      <AnimatePresence mode="wait">
                        {selected === "easypaisa" || selected === "jazzcash" ? (
                          <motion.div
                            key={selected}
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            className="overflow-hidden mb-5"
                          >
                            <div className="bg-card border border-card-border rounded-2xl p-4 space-y-3">
                              <div className="flex items-center gap-2">
                                <Smartphone className="h-4 w-4 text-primary" />
                                <p className="text-sm font-medium">Send payment to:</p>
                              </div>
                              <div className="bg-primary/10 rounded-xl px-4 py-3 text-center">
                                <p className="text-xs text-muted-foreground">Account Number</p>
                                <p className="text-lg font-bold text-primary mt-0.5">{MOCK_ACCOUNT[selected]}</p>
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="txn">Transaction ID / Reference</Label>
                                <Input
                                  id="txn"
                                  data-testid="input-transaction-id"
                                  placeholder="e.g. TXN123456789"
                                  value={transactionId}
                                  onChange={(e) => setTransactionId(e.target.value)}
                                />
                                <p className="text-xs text-muted-foreground">Enter the transaction ID shown in your {selected === "easypaisa" ? "EasyPaisa" : "JazzCash"} app</p>
                              </div>
                            </div>
                          </motion.div>
                        ) : selected === "card" ? (
                          <motion.div
                            key="card"
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            className="overflow-hidden mb-5"
                          >
                            <div className="bg-card border border-card-border rounded-2xl p-4 space-y-3">
                              <div className="space-y-2">
                                <Label htmlFor="cardNum">Card Number</Label>
                                <Input
                                  id="cardNum"
                                  data-testid="input-card-number"
                                  placeholder="1234 5678 9012 3456"
                                  maxLength={19}
                                  value={cardNumber}
                                  onChange={(e) => {
                                    const v = e.target.value.replace(/\D/g, "").slice(0, 16);
                                    setCardNumber(v.replace(/(.{4})/g, "$1 ").trim());
                                  }}
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-2">
                                  <Label htmlFor="expiry">Expiry</Label>
                                  <Input
                                    id="expiry"
                                    data-testid="input-card-expiry"
                                    placeholder="MM/YY"
                                    maxLength={5}
                                    value={cardExpiry}
                                    onChange={(e) => {
                                      const v = e.target.value.replace(/\D/g, "").slice(0, 4);
                                      setCardExpiry(v.length > 2 ? `${v.slice(0,2)}/${v.slice(2)}` : v);
                                    }}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="cvv">CVV</Label>
                                  <Input
                                    id="cvv"
                                    data-testid="input-card-cvv"
                                    placeholder="123"
                                    maxLength={3}
                                    type="password"
                                    value={cardCvv}
                                    onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
                                  />
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ) : null}
                      </AnimatePresence>

                      <Button
                        data-testid="button-pay"
                        size="lg"
                        className="w-full"
                        disabled={!canPay || payMutation.isPending}
                        onClick={handlePay}
                      >
                        {payMutation.isPending ? (
                          <><Loader className="mr-2 h-4 w-4 animate-spin" /> Processing…</>
                        ) : (
                          <>Pay Rs {(request.estimatedCost ?? 0).toLocaleString()}</>
                        )}
                      </Button>

                      <p className="text-center text-xs text-muted-foreground mt-3">
                        🔒 Your payment is secure and encrypted
                      </p>
                    </>
                  )}
                </>
              ) : (
                <p className="text-center text-muted-foreground">Request not found</p>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}
