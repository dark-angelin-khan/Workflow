import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/hooks/use-auth";
import { NotificationsProvider } from "@/hooks/use-notifications";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Register from "@/pages/register";
import ClientDashboard from "@/pages/client-dashboard";
import RequestService from "@/pages/request-service";
import Tracking from "@/pages/tracking";
import Chat from "@/pages/chat";
import MechanicDashboard from "@/pages/mechanic-dashboard";
import MechanicRequest from "@/pages/mechanic-request";
import Reviews from "@/pages/reviews";
import Rate from "@/pages/rate";
import Payment from "@/pages/payment";
import Earnings from "@/pages/earnings";
import Profile from "@/pages/profile";
import Clients from "@/pages/clients";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/client-dashboard" component={ClientDashboard} />
      <Route path="/request-service" component={RequestService} />
      <Route path="/tracking/:id" component={Tracking} />
      <Route path="/chat/:id" component={Chat} />
      <Route path="/mechanic-dashboard" component={MechanicDashboard} />
      <Route path="/mechanic-request/:id" component={MechanicRequest} />
      <Route path="/reviews" component={Reviews} />
      <Route path="/rate/:id" component={Rate} />
      <Route path="/payment/:id" component={Payment} />
      <Route path="/earnings" component={Earnings} />
      <Route path="/profile" component={Profile} />
      <Route path="/clients" component={Clients} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="mechconnect-theme">
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <NotificationsProvider>
            <TooltipProvider>
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                <Router />
              </WouterRouter>
              <Toaster />
            </TooltipProvider>
          </NotificationsProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
