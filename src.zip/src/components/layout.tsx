import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useNotifications } from "@/hooks/use-notifications";
import { Wrench, MapPin, User, LogOut, Moon, Sun, Home, History, Bell, Users } from "lucide-react";
import { useTheme } from "./theme-provider";
import { Button } from "./ui/button";
import { motion, AnimatePresence } from "framer-motion";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const { pendingCount, permissionGranted, requestPermission } = useNotifications();

  const isMechanic = user?.role === "mechanic";

  return (
    <div className="flex flex-col min-h-[100dvh] bg-background text-foreground">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 max-w-screen-2xl items-center justify-between">
          <Link
            href={user ? (isMechanic ? "/mechanic-dashboard" : "/client-dashboard") : "/"}
            className="flex items-center gap-2 font-bold text-lg"
          >
            <Wrench className="h-5 w-5 text-primary" />
            <span>Mech<span className="text-primary">Connect</span></span>
          </Link>

          <div className="flex items-center gap-2">
            {/* Bell icon for mechanics on desktop */}
            {isMechanic && (
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={() => !permissionGranted && requestPermission()}
                title={permissionGranted ? "Notifications on" : "Enable notifications"}
              >
                <Bell className={`h-5 w-5 ${permissionGranted ? "text-primary" : "text-muted-foreground"}`} />
                <AnimatePresence>
                  {pendingCount > 0 && (
                    <motion.span
                      key="badge"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                      className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center"
                    >
                      {pendingCount > 9 ? "9+" : pendingCount}
                    </motion.span>
                  )}
                </AnimatePresence>
              </Button>
            )}

            <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            </Button>

            {user ? (
              <Button variant="ghost" size="icon" onClick={() => logout()}>
                <LogOut className="h-5 w-5" />
              </Button>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Button variant="ghost" asChild>
                  <Link href="/login">Log in</Link>
                </Button>
                <Button asChild>
                  <Link href="/register">Sign up</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col w-full pb-16 sm:pb-0">
        {children}
      </main>

      {user && (
        <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around border-t bg-background px-4 py-3 pb-safe">
          {/* Home */}
          <Link
            href={isMechanic ? "/mechanic-dashboard" : "/client-dashboard"}
            className={`flex flex-col items-center gap-1 relative ${location.includes("dashboard") ? "text-primary" : "text-muted-foreground"}`}
          >
            <div className="relative">
              <Home className="h-5 w-5" />
              <AnimatePresence>
                {isMechanic && pendingCount > 0 && (
                  <motion.span
                    key="nav-badge"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    className="absolute -top-1.5 -right-2 min-w-[16px] h-[16px] px-0.5 rounded-full bg-destructive text-destructive-foreground text-[9px] font-bold flex items-center justify-center"
                  >
                    {pendingCount > 9 ? "9+" : pendingCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
            <span className="text-[10px] font-medium">Home</span>
          </Link>

          {/* Request (client only) */}
          {!isMechanic && (
            <Link
              href="/request-service"
              className={`flex flex-col items-center gap-1 ${location === "/request-service" ? "text-primary" : "text-muted-foreground"}`}
            >
              <MapPin className="h-5 w-5" />
              <span className="text-[10px] font-medium">Request</span>
            </Link>
          )}

          {/* Bell (mechanic only) — tapping enables notifications */}
          {isMechanic && (
            <button
              className={`flex flex-col items-center gap-1 ${permissionGranted ? "text-primary" : "text-muted-foreground"}`}
              onClick={() => !permissionGranted && requestPermission()}
            >
              <Bell className="h-5 w-5" />
              <span className="text-[10px] font-medium">Alerts</span>
            </button>
          )}

          {/* Clients (mechanic only) */}
          {isMechanic ? (
            <Link
              href="/clients"
              className={`flex flex-col items-center gap-1 ${location === "/clients" ? "text-primary" : "text-muted-foreground"}`}
            >
              <Users className="h-5 w-5" />
              <span className="text-[10px] font-medium">Clients</span>
            </Link>
          ) : (
            <Link
              href="/reviews"
              className={`flex flex-col items-center gap-1 ${location === "/reviews" ? "text-primary" : "text-muted-foreground"}`}
            >
              <History className="h-5 w-5" />
              <span className="text-[10px] font-medium">Reviews</span>
            </Link>
          )}

          {/* Profile */}
          <Link
            href="/profile"
            className={`flex flex-col items-center gap-1 ${location === "/profile" ? "text-primary" : "text-muted-foreground"}`}
          >
            <User className="h-5 w-5" />
            <span className="text-[10px] font-medium">Profile</span>
          </Link>
        </nav>
      )}
    </div>
  );
}
