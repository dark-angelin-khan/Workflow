import { createContext, useContext, useEffect, useRef, useState, ReactNode } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useListMechanics, getListMechanicsQueryKey, useGetMechanicDashboard, getGetMechanicDashboardQueryKey } from "@workspace/api-client-react";

interface NotificationsContextType {
  pendingCount: number;
  permissionGranted: boolean;
  requestPermission: () => Promise<void>;
}

const NotificationsContext = createContext<NotificationsContextType>({
  pendingCount: 0,
  permissionGranted: false,
  requestPermission: async () => {},
});

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const isMechanic = user?.role === "mechanic";

  const [permissionGranted, setPermissionGranted] = useState(
    () => typeof Notification !== "undefined" && Notification.permission === "granted"
  );
  const prevCountRef = useRef<number | null>(null);

  const { data: mechanics } = useListMechanics({
    query: {
      enabled: isMechanic,
      queryKey: getListMechanicsQueryKey(),
    },
  });

  const myMechanic = mechanics?.find((m) => m.userId === user?.id);

  const { data: dashboard } = useGetMechanicDashboard(myMechanic?.id ?? 0, {
    query: {
      enabled: isMechanic && !!myMechanic?.id,
      queryKey: getGetMechanicDashboardQueryKey(myMechanic?.id ?? 0),
      refetchInterval: isMechanic ? 5000 : false,
    },
  });

  const pendingCount = dashboard?.pendingRequests?.length ?? 0;

  useEffect(() => {
    if (!isMechanic) return;
    if (prevCountRef.current === null) {
      prevCountRef.current = pendingCount;
      return;
    }
    if (pendingCount > prevCountRef.current) {
      const diff = pendingCount - prevCountRef.current;
      if (permissionGranted && typeof Notification !== "undefined") {
        new Notification("MechConnect — New Request!", {
          body: `${diff} new service request${diff > 1 ? "s" : ""} waiting for you`,
          icon: "/favicon.ico",
          tag: "mechconnect-new-request",
        });
      }
    }
    prevCountRef.current = pendingCount;
  }, [pendingCount, isMechanic, permissionGranted]);

  const requestPermission = async () => {
    if (typeof Notification === "undefined") return;
    const result = await Notification.requestPermission();
    setPermissionGranted(result === "granted");
  };

  return (
    <NotificationsContext.Provider value={{ pendingCount, permissionGranted, requestPermission }}>
      {children}
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  return useContext(NotificationsContext);
}
